USE Student;
GO

INSERT INTO student (FirstName, LastName, Email, MobileNumber, EnrollmentNo, DateOfBirth, Gender, Address) 
VALUES 
('harsha', 'vardhan', 'harsha@gmail.com', '9008112377', '12107150', '2003-06-28', 'Male', 'LPU'),
('Tharun', 'Reddy', 'Tharun@gmail.com', '91108112387', '1205161', '2000-11-18', 'Male', 'Nellore'),
('Akash', 'Naga', 'akash@gmail.com', '9902212376', '12102220', '2001-05-06', 'Male', 'Bangalore'),
('Sasi', 'dher', 'sasi@gmail.com', '94348122327', '1204462', '2002-12-27', 'Male', 'Nellore'),
('Narasimha', 'Raju', 'raju@gmail.com', '91242792390', '1208661', '2001-09-18', 'Male', 'Bangalore');
GO
